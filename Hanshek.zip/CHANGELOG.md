# 0.1.1

Replaced Consume with Imprecation

# 0.1.0

Initial concept
